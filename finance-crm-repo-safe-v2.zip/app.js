(() => {
  const CONFIG = window.FINANCE_CRM_CONFIG || {};
  const MONTH_ORDER = ['JAN','FEB','MAR','APR','MEI','JUN','JUL','AGUST','SEPT','OKT','NOV','DES'];
  const MONTH_LABEL = {JAN:'Jan',FEB:'Feb',MAR:'Mar',APR:'Apr',MEI:'Mei',JUN:'Jun',JUL:'Jul',AGUST:'Agu',SEPT:'Sep',OKT:'Okt',NOV:'Nov',DES:'Des'};
  const PAGE_META = {
    overview:['Financial Overview','Ringkasan arus kas dan kesehatan data'],
    projects:['Project Finance','Rangkuman movement per project dengan drill-down'],
    obligations:['Hutang, Pinjaman & Tagihan','Movement terkait kewajiban, pinjaman, tagihan, dan titipan'],
    accounts:['Account & Origin','Movement berdasarkan rekening / sumber transaksi'],
    categories:['Category Analysis','Komposisi dan ranking kategori transaksi'],
    transactions:['Transaction Ledger','Detail seluruh transaksi dengan filter dan pencarian'],
    insights:['Finance Insights','Temuan berbasis data dan kontrol yang perlu diperkuat']
  };
  const state = {
    allRows: [], rows: [], mode: 'snapshot', view: 'overview', accessToken: null,
    filters: {search:'',month:'ALL',type:'ALL',origin:'ALL'}, page:1, perPage:30, sort:'date-desc'
  };
  let resizeTimer = null, toastTimer = null;

  const $ = s => document.querySelector(s);
  const $$ = s => [...document.querySelectorAll(s)];
  const esc = s => String(s ?? '').replace(/[&<>'"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[m]));
  const clamp = (v,a,b)=>Math.min(b,Math.max(a,v));
  const sum = (arr, key) => arr.reduce((a,r)=>a+(+r[key]||0),0);
  const money = n => new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:0}).format(n||0);
  const compact = n => new Intl.NumberFormat('id-ID',{notation:'compact',maximumFractionDigits:1}).format(n||0);
  const num = n => new Intl.NumberFormat('id-ID').format(n||0);
  const dateLabel = s => { if(!s) return '-'; const d=new Date(s+'T00:00:00'); return Number.isNaN(d)?s:new Intl.DateTimeFormat('id-ID',{day:'2-digit',month:'short',year:'numeric'}).format(d); };
  const netClass = n => n < 0 ? 'negative' : n > 0 ? 'positive' : '';
  const normalizeOrigin = value => {
    const v=(value||'Tidak diketahui').trim(); const u=v.toUpperCase();
    if(u==='MANDIRI') return 'MANDIRI'; if(u==='BCA') return 'BCA'; if(u==='BNI') return 'BNI'; if(u==='CASH') return 'CASH';
    if(u==='BNI PT CSK') return 'BNI PT CSK'; if(u==='PERUSAHAAN') return 'Perusahaan'; if(u==='PRIBADI') return 'Pribadi';
    return v;
  };
  const groupBy = (rows, keyFn) => {
    const m = new Map();
    rows.forEach(r=>{ const k=keyFn(r)||'Tidak diketahui'; if(!m.has(k))m.set(k,[]); m.get(k).push(r); }); return m;
  };
  const aggregate = (rows, keyFn) => [...groupBy(rows,keyFn)].map(([name,items])=>({
    name, cashIn:sum(items,'cashIn'), cashOut:sum(items,'cashOut'), net:sum(items,'cashIn')-sum(items,'cashOut'), transactions:items.length, items
  }));
  const totalMovement = r => (r.cashIn||0)+(r.cashOut||0);

  function toast(msg){ const t=$('#toast'); t.textContent=msg; t.classList.add('show'); clearTimeout(toastTimer); toastTimer=setTimeout(()=>t.classList.remove('show'),2800); }
  function setMode(mode){ state.mode=mode; const badge=$('#modeBadge'); badge.innerHTML=`<span class="dot ${mode==='live'?'ok':''}"></span><span>${mode==='live'?'Live Google':'Snapshot'}</span>`; }

  async function loadSnapshot(){
    const res=await fetch(CONFIG.snapshotUrl||'data/snapshot.json',{cache:'no-store'}); if(!res.ok) throw new Error('Snapshot tidak ditemukan');
    const data=await res.json(); state.allRows=(data.rows||[]).map(normalizeRow); setMode('snapshot'); applyFilters(); toast(`Snapshot loaded · ${num(state.allRows.length)} transaksi`);
  }
  function normalizeRow(r,i){ return {id:r.id||i+1,date:r.date||'',description:r.description||'',cashIn:+r.cashIn||0,cashOut:+r.cashOut||0,balance:+r.balance||0,origin:r.origin||'',category:r.category||'',detail:r.detail||'',month:(r.month||'').toUpperCase(),type:r.type||'UNCLASSIFIED'}; }
  function parseMoney(v){ if(typeof v==='number')return v; const s=String(v||'').replace(/Rp|\s/g,'').replace(/,/g,'').replace(/[^0-9.-]/g,''); return +s||0; }
  function parseDate(v){ const s=String(v||'').trim(); const m=s.match(/^(\d{1,2})-(\d{1,2})-(\d{4})$/); if(m) return `${m[3]}-${m[2].padStart(2,'0')}-${m[1].padStart(2,'0')}`; return s; }

  function populateFilters(){
    const months=[...new Set(state.allRows.map(r=>r.month).filter(Boolean))].sort((a,b)=>MONTH_ORDER.indexOf(a)-MONTH_ORDER.indexOf(b));
    $('#monthFilter').innerHTML='<option value="ALL">Semua bulan</option>'+months.map(m=>`<option value="${esc(m)}">${MONTH_LABEL[m]||m}</option>`).join('');
    const types=[...new Set(state.allRows.map(r=>r.type).filter(Boolean))].sort();
    $('#typeFilter').innerHTML='<option value="ALL">Semua tipe</option>'+types.map(t=>`<option value="${esc(t)}">${esc(t)}</option>`).join('');
    const origins=[...new Set(state.allRows.map(r=>normalizeOrigin(r.origin)).filter(Boolean))].sort();
    $('#originFilter').innerHTML='<option value="ALL">Semua origin</option>'+origins.map(o=>`<option value="${esc(o)}">${esc(o)}</option>`).join('');
  }
  function applyFilters(){
    const f=state.filters, q=f.search.trim().toLowerCase();
    state.rows=state.allRows.filter(r=>(f.month==='ALL'||r.month===f.month)&&(f.type==='ALL'||r.type===f.type)&&(f.origin==='ALL'||normalizeOrigin(r.origin)===f.origin)&&(!q||[r.description,r.category,r.origin,r.detail,r.type,r.month].some(v=>String(v||'').toLowerCase().includes(q))));
    state.page=1; populateFiltersKeepSelection(); renderAll();
  }
  function populateFiltersKeepSelection(){
    const old={...state.filters}; populateFilters(); $('#monthFilter').value=old.month; $('#typeFilter').value=old.type; $('#originFilter').value=old.origin;
  }

  function kpi(label,value,sub='',cls=''){ return `<div class="kpi"><div class="label">${esc(label)}</div><div class="value">${value}</div><div class="sub ${cls}">${sub}</div></div>`; }
  function renderAll(){ renderOverview(); renderProjects(); renderObligations(); renderAccounts(); renderCategories(); renderTransactions(); renderInsights(); }
  function renderOverview(){
    const rows=state.rows, cashIn=sum(rows,'cashIn'), cashOut=sum(rows,'cashOut'), net=cashIn-cashOut, nonCap=rows.filter(r=>r.type!=='CAPITAL'), nci=sum(nonCap,'cashIn'), nco=sum(nonCap,'cashOut'), nn=nci-nco, cov=nco? nci/nco:0;
    $('#overviewKpis').innerHTML=[
      kpi('Cash In',money(cashIn),`${num(rows.filter(r=>r.cashIn>0).length)} transaksi masuk`),
      kpi('Cash Out',money(cashOut),`${num(rows.filter(r=>r.cashOut>0).length)} transaksi keluar`),
      kpi('Net Movement',money(net),'Cash in − cash out',net>=0?'good':'bad'),
      kpi('Non-capital Net',money(nn),'Mengecualikan tipe CAPITAL',nn>=0?'good':'bad'),
      kpi('Transactions',num(rows.length),'Sesuai filter aktif'),
      kpi('Coverage Ratio',cov?`${cov.toFixed(2)}×`:'—','Non-capital in ÷ out',cov>=1?'good':'bad')
    ].join('');
    const monthAgg=aggregate(rows,r=>r.month).sort((a,b)=>MONTH_ORDER.indexOf(a.name)-MONTH_ORDER.indexOf(b.name));
    comboChart($('#monthlyChart'),monthAgg.map(x=>({label:MONTH_LABEL[x.name]||x.name,a:x.cashIn,b:x.cashOut,line:x.net})),{a:'Cash In',b:'Cash Out',line:'Net'});
    const typeAgg=aggregate(rows,r=>r.type).sort((a,b)=>b.transactions-a.transactions); donut($('#typeDonut'),typeAgg.map(x=>({label:x.name,value:x.cashIn+x.cashOut})), 'Movement');
    const expenses=aggregate(rows,r=>r.category||'Tanpa kategori').sort((a,b)=>b.cashOut-a.cashOut).filter(x=>x.cashOut>0).slice(0,10);
    hbars($('#topExpenseChart'),expenses.map(x=>({label:x.name,value:x.cashOut})), 'Cash Out');
    const capitalIn=sum(rows.filter(r=>r.type==='CAPITAL'),'cashIn');
    $('#nonCapitalPanel').innerHTML=`<div class="mini-stats"><div class="mini-stat"><span>Non-capital Cash In</span><b>${money(nci)}</b><div class="progress"><i style="width:${clamp(cashIn?nci/cashIn*100:0,0,100)}%"></i></div></div><div class="mini-stat"><span>Non-capital Cash Out</span><b>${money(nco)}</b><div class="progress"><i style="width:${clamp(cashOut?nco/cashOut*100:0,0,100)}%"></i></div></div><div class="mini-stat"><span>Capital-classified In</span><b>${money(capitalIn)}</b><small class="muted">Termasuk modal / carry-over yang terklasifikasi CAPITAL.</small></div><div class="mini-stat"><span>Non-capital Net</span><b class="money-net ${netClass(nn)}">${money(nn)}</b><small class="muted">Indikator movement, bukan laba bersih.</small></div></div>`;
    const recent=[...rows].sort((a,b)=>b.date.localeCompare(a.date)||b.id-a.id).slice(0,10); $('#recentTransactions').innerHTML=recent.map(txRow).join('')||emptyRow(6);
  }

  function renderProjects(){
    const projectRows=state.rows.filter(r=>r.type==='PROJECT'), agg=aggregate(projectRows,r=>r.category||'Tanpa project').sort((a,b)=>b.cashOut-a.cashOut), ci=sum(projectRows,'cashIn'), co=sum(projectRows,'cashOut'), net=ci-co;
    $('#projectKpis').innerHTML=[kpi('Project Cash In',money(ci),`${agg.length} project/category`),kpi('Project Cash Out',money(co),`${projectRows.length} transaksi`),kpi('Net Movement',money(net),'Bukan profit akuntansi',net>=0?'good':'bad'),kpi('Project Count',num(agg.length),'Kategori bertipe PROJECT'),kpi('Avg Out / Project',money(agg.length?co/agg.length:0),'Rata-rata cash-out'),kpi('Top Outflow',agg[0]?esc(agg[0].name):'—',agg[0]?money(agg[0].cashOut):'')].join('');
    hbars($('#projectChart'),agg.slice(0,12).map(x=>({label:x.name,value:x.cashOut,secondary:x.cashIn})), 'Cash Out');
    donut($('#projectDonut'),agg.slice(0,7).map(x=>({label:x.name,value:x.cashOut})), 'Project Out');
    const totalOut=co||1; $('#projectTable').innerHTML=agg.map(x=>`<tr class="clickable" data-group="project" data-name="${attr(x.name)}"><td><b>${esc(x.name)}</b></td><td class="money-in">${money(x.cashIn)}</td><td class="money-out">${money(x.cashOut)}</td><td class="money-net ${netClass(x.net)}">${money(x.net)}</td><td>${num(x.transactions)}</td><td>${(x.cashOut/totalOut*100).toFixed(1)}%</td></tr>`).join('')||emptyRow(6);
  }

  function renderObligations(){
    const rows=state.rows.filter(r=>r.type==='DEBT / RECEIVABLE'), agg=aggregate(rows,r=>r.category||'Tanpa kategori').sort((a,b)=>(b.cashIn+b.cashOut)-(a.cashIn+a.cashOut)), ci=sum(rows,'cashIn'), co=sum(rows,'cashOut'), net=ci-co;
    $('#obligationKpis').innerHTML=[kpi('Related Cash In',money(ci),'Masuk pada kategori terkait'),kpi('Related Cash Out',money(co),'Keluar pada kategori terkait'),kpi('Net Movement',money(net),'Belum membedakan payable/receivable',net>=0?'good':'bad'),kpi('Transactions',num(rows.length),'Transaksi terklasifikasi'),kpi('Categories',num(agg.length),'Kategori terkait'),kpi('Largest Movement',agg[0]?esc(agg[0].name):'—',agg[0]?money(agg[0].cashIn+agg[0].cashOut):'')].join('');
    hbars($('#obligationChart'),agg.slice(0,12).map(x=>({label:x.name,value:x.cashOut,secondary:x.cashIn})), 'Cash Out');
    $('#obligationRank').innerHTML=agg.slice(0,10).map((x,i)=>`<div class="rank-item clickable" data-group="obligation" data-name="${attr(x.name)}"><div class="rank-n">${i+1}</div><div><b>${esc(x.name)}</b><small>${num(x.transactions)} transaksi · Net ${money(x.net)}</small></div><strong>${compact(x.cashIn+x.cashOut)}</strong></div>`).join('')||'<div class="chart-empty">Tidak ada data</div>';
    $('#obligationTable').innerHTML=[...rows].sort((a,b)=>b.date.localeCompare(a.date)).slice(0,100).map(r=>`<tr class="clickable" data-tx="${r.id}"><td>${dateLabel(r.date)}</td><td>${esc(r.description)}</td><td>${esc(r.category)}</td><td>${esc(normalizeOrigin(r.origin))}</td><td class="money-in">${r.cashIn?money(r.cashIn):''}</td><td class="money-out">${r.cashOut?money(r.cashOut):''}</td><td>${esc(r.month)}</td></tr>`).join('')||emptyRow(7);
  }

  function renderAccounts(){
    const agg=aggregate(state.rows,r=>normalizeOrigin(r.origin)).sort((a,b)=>(b.cashIn+b.cashOut)-(a.cashIn+a.cashOut)), ci=sum(state.rows,'cashIn'),co=sum(state.rows,'cashOut');
    const bankish=agg.filter(x=>['BCA','BNI','MANDIRI','BNI PT CSK','CASH'].includes(x.name));
    $('#accountKpis').innerHTML=[kpi('Origins',num(agg.length),'Label setelah normalisasi'),kpi('Bank/Cash Origins',num(bankish.length),'BCA / BNI / MANDIRI / CASH'),kpi('Total Movement',money(ci+co),'In + out'),kpi('Normalized Duplicates','MANDIRI','Mandiri digabung di tampilan'),kpi('Largest Origin',agg[0]?esc(agg[0].name):'—',agg[0]?money(agg[0].cashIn+agg[0].cashOut):''),kpi('Transactions',num(state.rows.length),'Sesuai filter')].join('');
    hbars($('#accountChart'),agg.slice(0,12).map(x=>({label:x.name,value:x.cashOut,secondary:x.cashIn})),'Cash Out');
    donut($('#accountDonut'),agg.slice(0,8).map(x=>({label:x.name,value:x.transactions})),'Transactions');
    $('#accountTable').innerHTML=agg.map(x=>`<tr class="clickable" data-group="origin" data-name="${attr(x.name)}"><td><b>${esc(x.name)}</b></td><td class="money-in">${money(x.cashIn)}</td><td class="money-out">${money(x.cashOut)}</td><td class="money-net ${netClass(x.net)}">${money(x.net)}</td><td>${num(x.transactions)}</td></tr>`).join('')||emptyRow(5);
  }

  function renderCategories(){
    const agg=aggregate(state.rows,r=>r.category||'Tanpa kategori').map(x=>({...x,type:x.items[0]?.type||'UNCLASSIFIED'})).sort((a,b)=>b.cashOut-a.cashOut), typeAgg=aggregate(agg.map(x=>({type:x.type,cashIn:0,cashOut:0})),r=>r.type);
    const withOut=agg.filter(x=>x.cashOut>0); $('#categoryKpis').innerHTML=[kpi('Categories',num(agg.length),'Kategori unik'),kpi('With Cash Out',num(withOut.length),'Kategori dengan pengeluaran'),kpi('Top Expense',agg[0]?esc(agg[0].name):'—',agg[0]?money(agg[0].cashOut):''),kpi('Project Categories',num(agg.filter(x=>x.type==='PROJECT').length),'Tipe PROJECT'),kpi('Obligation Categories',num(agg.filter(x=>x.type==='DEBT / RECEIVABLE').length),'Pinjaman / hutang / tagihan / titipan'),kpi('Operating / Other',num(agg.filter(x=>x.type==='OPERATING / OTHER').length),'Kategori operasional/lainnya')].join('');
    hbars($('#categoryChart'),agg.slice(0,14).map(x=>({label:x.name,value:x.cashOut})),'Cash Out');
    const counts=[...new Set(agg.map(x=>x.type))].map(t=>({label:t,value:agg.filter(x=>x.type===t).length})); donut($('#categoryTypeDonut'),counts,'Categories');
    $('#categoryTable').innerHTML=agg.map(x=>`<tr class="clickable" data-group="category" data-name="${attr(x.name)}"><td><b>${esc(x.name)}</b></td><td><span class="pill">${esc(x.type)}</span></td><td class="money-in">${money(x.cashIn)}</td><td class="money-out">${money(x.cashOut)}</td><td class="money-net ${netClass(x.net)}">${money(x.net)}</td><td>${num(x.transactions)}</td></tr>`).join('')||emptyRow(6);
  }

  function renderTransactions(){
    let rows=[...state.rows];
    switch(state.sort){case'date-asc':rows.sort((a,b)=>a.date.localeCompare(b.date)||a.id-b.id);break;case'out-desc':rows.sort((a,b)=>b.cashOut-a.cashOut);break;case'in-desc':rows.sort((a,b)=>b.cashIn-a.cashIn);break;default:rows.sort((a,b)=>b.date.localeCompare(a.date)||b.id-a.id)}
    const pages=Math.max(1,Math.ceil(rows.length/state.perPage)); state.page=clamp(state.page,1,pages); const slice=rows.slice((state.page-1)*state.perPage,state.page*state.perPage);
    $('#transactionCount').textContent=`${num(rows.length)} transaksi sesuai filter`; $('#transactionTable').innerHTML=slice.map(r=>`<tr class="clickable" data-tx="${r.id}"><td>${dateLabel(r.date)}</td><td>${esc(r.description)}</td><td>${esc(r.category)}</td><td><span class="pill">${esc(r.type)}</span></td><td>${esc(normalizeOrigin(r.origin))}</td><td>${esc(r.detail||'')}</td><td class="money-in">${r.cashIn?money(r.cashIn):''}</td><td class="money-out">${r.cashOut?money(r.cashOut):''}</td><td>${r.balance?money(r.balance):''}</td></tr>`).join('')||emptyRow(9);
    $('#pageInfo').textContent=`${state.page} / ${pages}`; $('#prevPage').disabled=state.page<=1; $('#nextPage').disabled=state.page>=pages;
  }

  function renderInsights(){
    const rows=state.rows, month=aggregate(rows,r=>r.month).sort((a,b)=>b.cashOut-a.cashOut), cats=aggregate(rows,r=>r.category||'Tanpa kategori').sort((a,b)=>b.cashOut-a.cashOut), projects=aggregate(rows.filter(r=>r.type==='PROJECT'),r=>r.category).sort((a,b)=>b.cashOut-a.cashOut), nonCap=rows.filter(r=>r.type!=='CAPITAL'), nci=sum(nonCap,'cashIn'), nco=sum(nonCap,'cashOut'), ratio=nco?nci/nco:0;
    const topMonth=month[0], topCat=cats[0], topProject=projects[0];
    $('#insightCards').innerHTML=[
      insight('▥','Peak cash-out month',topMonth?`<b>${MONTH_LABEL[topMonth.name]||topMonth.name}</b> mencatat cash-out ${money(topMonth.cashOut)} pada filter saat ini.`:'Belum ada data.'),
      insight('◆','Largest expense category',topCat?`<b>${esc(topCat.name)}</b> menyumbang cash-out ${money(topCat.cashOut)} dari data terfilter.`:'Belum ada data.'),
      insight('◉','Non-capital coverage',ratio?`Rasio cash-in terhadap cash-out non-capital adalah <b>${ratio.toFixed(2)}×</b>. Gunakan sebagai indikator movement, bukan profit.`:'Belum dapat dihitung.'),
      insight('↔','Project concentration',topProject?`Project/category dengan cash-out terbesar adalah <b>${esc(topProject.name)}</b> sebesar ${money(topProject.cashOut)}.`:'Belum ada data project.'),
      insight('⌁','Capital treatment',`Transaksi bertipe CAPITAL dipisahkan agar carry-over/modal tidak tercampur dengan non-capital movement.`),
      insight('✓','Drill-down ready',`Semua ringkasan dapat ditelusuri ke transaksi sumber melalui baris tabel dan detail drawer.`)
    ].join('');
    const controls=[
      ['High','Tambahkan master Project Code','Saat ini project diproksikan dari CATEGORY. Project Code terpisah akan mencegah kategori operasional tercampur dengan proyek.'],
      ['High','Pisahkan AR dan AP','Kategori pinjaman/hutang/tagihan/titipan belum membedakan piutang vs hutang. Tambahkan counterparty, direction, due date, status, invoice/ref.'],
      ['High','Pisahkan Opening Balance','Carry-over/modal awal masuk sebagai Cash In. Tambahkan field opening_balance atau transaction_class agar cashflow periode tidak terinflasi.'],
      ['Medium','Standarkan Account / Origin','Jan–Mar banyak menggunakan Perusahaan/Pribadi, sedangkan Apr–Sep menggunakan rekening seperti BCA/MANDIRI/BNI. Gunakan master account konsisten.'],
      ['Medium','Tambahkan reconciliation status','Field matched_to_bank, reconciled_at, dan source_ref akan membuat angka dashboard bisa direkonsiliasi terhadap mutasi bank.'],
      ['Medium','Tambahkan project lifecycle','Status project, tanggal mulai/selesai, kontrak, budget, committed cost, receivable, payable akan memungkinkan profitability dan forecast yang benar.']
    ];
    $('#controlList').innerHTML=controls.map((x,i)=>`<div class="control-row"><div class="num">${i+1}</div><div><b>${esc(x[1])}</b><p>${esc(x[2])}</p></div><span class="priority">${x[0]}</span></div>`).join('');
  }
  function insight(icon,title,body){return `<article class="insight-card"><div class="icon">${icon}</div><h3>${title}</h3><p>${body}</p></article>`}

  function txRow(r){return `<tr class="clickable" data-tx="${r.id}"><td>${dateLabel(r.date)}</td><td>${esc(r.description)}</td><td>${esc(r.category)}</td><td>${esc(normalizeOrigin(r.origin))}</td><td class="money-in">${r.cashIn?money(r.cashIn):''}</td><td class="money-out">${r.cashOut?money(r.cashOut):''}</td></tr>`}
  function emptyRow(n){return `<tr><td colspan="${n}" class="muted" style="text-align:center;padding:28px">Tidak ada data untuk filter ini.</td></tr>`}
  function attr(s){return esc(s).replace(/`/g,'&#96;')}

  function showTransaction(id){ const r=state.allRows.find(x=>String(x.id)===String(id)); if(!r)return; $('#drawerEyebrow').textContent='TRANSACTION'; $('#drawerTitle').textContent=r.description||'Transaction'; $('#drawerBody').innerHTML=`<div class="detail-grid">${detailBox('Tanggal',dateLabel(r.date))}${detailBox('Month',r.month)}${detailBox('Category',r.category)}${detailBox('Type',r.type)}${detailBox('Origin',normalizeOrigin(r.origin))}${detailBox('Detail',r.detail||'—')}${detailBox('Cash In',r.cashIn?money(r.cashIn):'—')}${detailBox('Cash Out',r.cashOut?money(r.cashOut):'—')}${detailBox('Balance',r.balance?money(r.balance):'—')}${detailBox('Transaction ID',r.id)}</div>`; openDrawer(); }
  function showGroup(kind,name){ let rows=[]; if(kind==='project'||kind==='category'||kind==='obligation') rows=state.allRows.filter(r=>r.category===name); if(kind==='origin') rows=state.allRows.filter(r=>normalizeOrigin(r.origin)===name); const ci=sum(rows,'cashIn'),co=sum(rows,'cashOut'),net=ci-co; $('#drawerEyebrow').textContent=kind.toUpperCase(); $('#drawerTitle').textContent=name; $('#drawerBody').innerHTML=`<div class="detail-grid">${detailBox('Cash In',money(ci))}${detailBox('Cash Out',money(co))}${detailBox('Net Movement',money(net))}${detailBox('Transactions',num(rows.length))}</div><div class="subtable"><table><thead><tr><th>Date</th><th>Description</th><th>In</th><th>Out</th></tr></thead><tbody>${[...rows].sort((a,b)=>b.date.localeCompare(a.date)).map(r=>`<tr class="clickable" data-tx="${r.id}"><td>${dateLabel(r.date)}</td><td>${esc(r.description)}</td><td class="money-in">${r.cashIn?money(r.cashIn):''}</td><td class="money-out">${r.cashOut?money(r.cashOut):''}</td></tr>`).join('')}</tbody></table></div>`; openDrawer(); }
  function detailBox(k,v){return `<div class="detail-box"><span>${esc(k)}</span><b>${esc(v)}</b></div>`}
  function openDrawer(){ $('#drawerBackdrop').classList.add('open'); $('#detailDrawer').classList.add('open'); }
  function closeDrawer(){ $('#drawerBackdrop').classList.remove('open'); $('#detailDrawer').classList.remove('open'); }

  function chartColors(){ const c=getComputedStyle(document.documentElement); return {accent:c.getPropertyValue('--accent').trim(),accent2:c.getPropertyValue('--accent2').trim(),danger:c.getPropertyValue('--danger').trim(),muted:c.getPropertyValue('--muted').trim(),line:c.getPropertyValue('--line').trim(),text:c.getPropertyValue('--text').trim(),panel:c.getPropertyValue('--panel').trim()}; }
  function dims(el,minH=240){const w=Math.max(280,el.clientWidth-8), h=Math.max(minH,Math.min(380,w*.46));return{w,h}}
  function comboChart(el,data,labels){ if(!data.length){el.innerHTML='<div class="chart-empty">Tidak ada data</div>';return} const C=chartColors(),{w,h}=dims(el,250),pad={l:46,r:18,t:20,b:36},cw=w-pad.l-pad.r,ch=h-pad.t-pad.b,max=Math.max(...data.flatMap(d=>[d.a,d.b,Math.abs(d.line)]),1),step=cw/data.length,bar=Math.max(6,step*.22), y=v=>pad.t+ch-(v/max*ch), zero=y(0); let s=`<svg viewBox="0 0 ${w} ${h}" role="img">`; for(let i=0;i<5;i++){const yy=pad.t+ch*i/4;s+=`<line x1="${pad.l}" x2="${w-pad.r}" y1="${yy}" y2="${yy}" stroke="${C.line}" stroke-width="1" opacity=".55"/><text x="${pad.l-8}" y="${yy+3}" text-anchor="end" fill="${C.muted}" font-size="9">${compact(max*(1-i/4))}</text>`} let pts=[]; data.forEach((d,i)=>{const x=pad.l+step*i+step/2; const ha=d.a/max*ch,hb=d.b/max*ch; s+=`<rect data-tip="${attr(labels.a)}: ${attr(money(d.a))}" x="${x-bar-2}" y="${pad.t+ch-ha}" width="${bar}" height="${ha}" rx="3" fill="${C.accent}" opacity=".8"/><rect data-tip="${attr(labels.b)}: ${attr(money(d.b))}" x="${x+2}" y="${pad.t+ch-hb}" width="${bar}" height="${hb}" rx="3" fill="${C.danger}" opacity=".75"/><text x="${x}" y="${h-11}" text-anchor="middle" fill="${C.muted}" font-size="9">${esc(d.label)}</text>`; const ly=pad.t+ch-(d.line/max*ch); pts.push(`${x},${ly}`)}); s+=`<polyline points="${pts.join(' ')}" fill="none" stroke="${C.accent2}" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round"/>`; pts.forEach((p,i)=>{const[x,y]=p.split(',');s+=`<circle data-tip="${attr(labels.line)}: ${attr(money(data[i].line))}" cx="${x}" cy="${y}" r="3.5" fill="${C.accent2}" stroke="${C.panel}" stroke-width="2"/>`}); el.innerHTML=s+'</svg>'; wireTips(el); }
  function hbars(el,data,label){ if(!data.length){el.innerHTML='<div class="chart-empty">Tidak ada data</div>';return} const C=chartColors(),show=data.slice(0,14),{w}=dims(el,250),rowH=30,h=show.length*rowH+30,padL=Math.min(180,Math.max(105,w*.34)),right=18,max=Math.max(...show.map(x=>Math.max(x.value||0,x.secondary||0)),1),cw=w-padL-right; let s=`<svg viewBox="0 0 ${w} ${h}">`; show.forEach((d,i)=>{const y=12+i*rowH, bw=(d.value||0)/max*cw, sw=(d.secondary||0)/max*cw;s+=`<text x="${padL-8}" y="${y+12}" text-anchor="end" fill="${C.muted}" font-size="9">${esc(shorten(d.label,28))}</text><rect x="${padL}" y="${y}" width="${cw}" height="15" rx="5" fill="${C.line}" opacity=".35"/><rect data-tip="${attr(label)}: ${attr(money(d.value||0))}" x="${padL}" y="${y}" width="${bw}" height="7" rx="4" fill="${C.danger}" opacity=".82"/>`; if(d.secondary!=null)s+=`<rect data-tip="Cash In: ${attr(money(d.secondary||0))}" x="${padL}" y="${y+8}" width="${sw}" height="7" rx="4" fill="${C.accent}" opacity=".82"/>`; s+=`<text x="${padL+Math.max(bw,sw)+6}" y="${y+12}" fill="${C.text}" font-size="9">${compact(Math.max(d.value||0,d.secondary||0))}</text>`}); el.innerHTML=s+'</svg>'; wireTips(el); }
  function donut(el,data,centerLabel){ const valid=data.filter(x=>x.value>0).slice(0,8); if(!valid.length){el.innerHTML='<div class="chart-empty">Tidak ada data</div>';return} const C=chartColors(),palette=[C.accent,C.accent2,C.danger,'#f1bf62','#70d68d','#b18cff','#ff9f68','#6bd6ff'],total=valid.reduce((a,x)=>a+x.value,0),r=66,circ=2*Math.PI*r; let offset=0,s=`<svg viewBox="0 0 360 260"><g transform="translate(105 130) rotate(-90)">`; valid.forEach((d,i)=>{const len=d.value/total*circ;s+=`<circle data-tip="${attr(d.label)}: ${attr(compact(d.value))}" cx="0" cy="0" r="${r}" fill="none" stroke="${palette[i%palette.length]}" stroke-width="22" stroke-dasharray="${len} ${circ-len}" stroke-dashoffset="${-offset}"/>`;offset+=len});s+=`</g><text x="105" y="125" text-anchor="middle" fill="${C.text}" font-size="19" font-weight="800">${compact(total)}</text><text x="105" y="143" text-anchor="middle" fill="${C.muted}" font-size="9">${esc(centerLabel)}</text>`; valid.forEach((d,i)=>{const y=56+i*22;s+=`<rect x="206" y="${y-8}" width="8" height="8" rx="2" fill="${palette[i%palette.length]}"/><text x="220" y="${y}" fill="${C.muted}" font-size="9">${esc(shorten(d.label,20))}</text><text x="340" y="${y}" text-anchor="end" fill="${C.text}" font-size="9">${(d.value/total*100).toFixed(1)}%</text>`}); el.innerHTML=s+'</svg>'; wireTips(el); }
  function shorten(s,n){s=String(s||'');return s.length>n?s.slice(0,n-1)+'…':s}
  function wireTips(el){el.querySelectorAll('[data-tip]').forEach(node=>{node.addEventListener('pointerenter',e=>showTip(e,node.dataset.tip));node.addEventListener('pointermove',moveTip);node.addEventListener('pointerleave',hideTip)})}
  let tip=null; function showTip(e,text){tip=document.createElement('div');tip.className='tooltip';tip.textContent=text;document.body.appendChild(tip);moveTip(e)} function moveTip(e){if(tip){tip.style.left=(e.clientX+12)+'px';tip.style.top=(e.clientY+12)+'px'}} function hideTip(){tip?.remove();tip=null}

  function changeView(view){ if(!PAGE_META[view])return; state.view=view; $$('.view').forEach(v=>v.classList.toggle('active',v.id===`view-${view}`)); $$('[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===view)); $('#pageTitle').textContent=PAGE_META[view][0]; $('#pageSubtitle').textContent=PAGE_META[view][1]; window.scrollTo({top:0,behavior:'smooth'}); setTimeout(()=>renderAll(),60); }

  function openSettings(){ $('#settingsBackdrop').classList.add('open'); $('#settingsModal').classList.add('open'); $('#spreadsheetIdInput').value=localStorage.getItem('financeSheetId')||CONFIG.spreadsheetId||''; $('#clientIdInput').value=localStorage.getItem('financeGoogleClientId')||CONFIG.googleClientId||''; }
  function closeSettings(){ $('#settingsBackdrop').classList.remove('open'); $('#settingsModal').classList.remove('open'); }
  async function connectGoogle(){
    const clientId=localStorage.getItem('financeGoogleClientId')||CONFIG.googleClientId; const sheetId=localStorage.getItem('financeSheetId')||CONFIG.spreadsheetId;
    if(!clientId||!sheetId){openSettings();toast('Isi Google OAuth Client ID untuk live mode.');return}
    try{await ensureGoogleScript(); const tokenClient=google.accounts.oauth2.initTokenClient({client_id:clientId,scope:'https://www.googleapis.com/auth/spreadsheets.readonly',callback:async(resp)=>{if(resp.error){toast('Google authorization gagal');return}state.accessToken=resp.access_token;await loadLiveSheet(sheetId)}}); tokenClient.requestAccessToken({prompt:'consent'});}catch(e){console.error(e);toast('Tidak dapat memulai Google OAuth.');}
  }
  function ensureGoogleScript(){return new Promise((resolve,reject)=>{if(window.google?.accounts?.oauth2)return resolve(); const s=document.createElement('script');s.src='https://accounts.google.com/gsi/client';s.async=true;s.onload=resolve;s.onerror=reject;document.head.appendChild(s)})}
  async function loadLiveSheet(sheetId){
    toast('Mengambil WEB_DATA dari Google Sheets…'); const range=encodeURIComponent('WEB_DATA!A1:J10000'); const url=`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${range}?valueRenderOption=FORMATTED_VALUE`;
    const res=await fetch(url,{headers:{Authorization:`Bearer ${state.accessToken}`}}); if(!res.ok)throw new Error('Sheets API '+res.status); const data=await res.json(); const values=data.values||[]; if(values.length<2)throw new Error('WEB_DATA kosong');
    state.allRows=values.slice(1).filter(r=>r[0]).map((r,i)=>normalizeRow({id:i+1,date:parseDate(r[0]),description:r[1],cashIn:parseMoney(r[2]),cashOut:parseMoney(r[3]),balance:parseMoney(r[4]),origin:r[5],category:r[6],detail:r[7],month:r[8],type:r[9]},i)); setMode('live'); applyFilters(); toast(`Live sync selesai · ${num(state.allRows.length)} transaksi`);
  }

  function exportFilteredCsv(){ const cols=['date','description','cashIn','cashOut','balance','origin','category','detail','month','type']; const q=v=>`"${String(v??'').replace(/"/g,'""')}"`; const csv=[cols.join(','),...state.rows.map(r=>cols.map(c=>q(r[c])).join(','))].join('\n'); const blob=new Blob([csv],{type:'text/csv;charset=utf-8'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`finance-crm-${new Date().toISOString().slice(0,10)}.csv`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000); }

  function bind(){
    document.addEventListener('click',e=>{const v=e.target.closest('[data-view]');if(v)changeView(v.dataset.view);const g=e.target.closest('[data-goto]');if(g)changeView(g.dataset.goto);const tx=e.target.closest('[data-tx]');if(tx)showTransaction(tx.dataset.tx);const grp=e.target.closest('[data-group]');if(grp)showGroup(grp.dataset.group,grp.dataset.name)});
    $('#globalSearch').addEventListener('input',e=>{state.filters.search=e.target.value;applyFilters()}); $('#monthFilter').addEventListener('change',e=>{state.filters.month=e.target.value;applyFilters()}); $('#typeFilter').addEventListener('change',e=>{state.filters.type=e.target.value;applyFilters()}); $('#originFilter').addEventListener('change',e=>{state.filters.origin=e.target.value;applyFilters()});
    $('#clearFilters').onclick=()=>{state.filters={search:'',month:'ALL',type:'ALL',origin:'ALL'};$('#globalSearch').value='';applyFilters()}; $('#refreshBtn').onclick=()=>state.mode==='live'?(localStorage.getItem('financeSheetId')||CONFIG.spreadsheetId?loadLiveSheet(localStorage.getItem('financeSheetId')||CONFIG.spreadsheetId):connectGoogle()):loadSnapshot(); $('#connectBtn').onclick=connectGoogle;
    $('#openSettings').onclick=openSettings; $('#mobileSettings').onclick=openSettings; $('#closeSettings').onclick=closeSettings; $('#settingsBackdrop').onclick=closeSettings; $('#saveSettings').onclick=()=>{localStorage.setItem('financeSheetId',$('#spreadsheetIdInput').value.trim());localStorage.setItem('financeGoogleClientId',$('#clientIdInput').value.trim());closeSettings();connectGoogle()}; $('#useSnapshot').onclick=()=>{closeSettings();loadSnapshot()};
    $('#closeDrawer').onclick=closeDrawer; $('#drawerBackdrop').onclick=closeDrawer; $('#sortTransactions').onchange=e=>{state.sort=e.target.value;renderTransactions()}; $('#prevPage').onclick=()=>{state.page--;renderTransactions()}; $('#nextPage').onclick=()=>{state.page++;renderTransactions()}; $('#exportCsv').onclick=exportFilteredCsv;
    $('#mobileMenu').onclick=()=>openSettings();
    window.addEventListener('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(renderAll,180)}); if('serviceWorker'in navigator && location.protocol.startsWith('http'))navigator.serviceWorker.register('sw.js').catch(()=>{});
  }

  async function init(){bind(); try{await loadSnapshot()}catch(e){console.error(e);toast('Snapshot gagal dimuat. Gunakan Live Google mode.');state.allRows=[];applyFilters()} }
  init();
})();
