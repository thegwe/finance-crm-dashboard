window.FINANCE_CRM_CONFIG = {
  spreadsheetId: "YOUR_GOOGLE_SHEET_ID",
  googleClientId: "YOUR_OAUTH_CLIENT_ID.apps.googleusercontent.com",
  snapshotUrl: "data/snapshot.json",
  defaultMode: "snapshot"
};
