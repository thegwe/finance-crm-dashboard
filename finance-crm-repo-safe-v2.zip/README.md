# Finance CRM Dashboard

Dashboard cashflow responsive (HP + PC) untuk data `CASHFLOW - RAPI`.

## Modul
- Overview: KPI, cash movement bulanan, composition, top expense, non-capital view.
- Projects: ringkasan project/category, cash in/out, net cash movement, drill-down transaksi.
- Obligations: transaksi pinjaman/hutang/tagihan/titipan (berdasarkan klasifikasi kategori).
- Accounts: movement per account/origin dengan normalisasi label.
- Categories: ranking kategori dan komposisi tipe.
- Transactions: searchable/filterable ledger, pagination, export CSV, detail drawer.
- Insights: data-driven observations + data quality / finance controls.

## Keamanan
`data/snapshot.json` berisi snapshot transaksi nyata dan **sudah dimasukkan ke `.gitignore`**. Jangan commit file ini ke repository.

Live mode memakai Google OAuth scope:
`https://www.googleapis.com/auth/spreadsheets.readonly`

Access token hanya berada di sesi browser dan tidak ditulis ke source code.

## Jalankan lokal
Karena browser membatasi `fetch()` dari `file://`, jalankan folder dengan static server.

Python:
```bash
python -m http.server 8080
```
Lalu buka `http://localhost:8080`.

## Live Google Sheets
1. Enable **Google Sheets API** di Google Cloud project.
2. Buat **OAuth 2.0 Client ID** tipe Web application.
3. Tambahkan origin hosting / localhost ke Authorized JavaScript origins.
4. Copy `config.example.js` menjadi `config.js`, atau isi Client ID melalui Settings di dashboard.
5. Klik `Connect Google` dan login dengan akun yang punya akses ke spreadsheet.

Spreadsheet default yang digunakan aplikasi lokal sudah mengarah ke `CASHFLOW - RAPI`.

## Deploy
Aplikasi ini static dan dapat dideploy ke Vercel, Netlify, Cloudflare Pages, atau static hosting lain. Repo boleh private. Pastikan hanya source code yang dipush; jangan push `data/snapshot.json` dan `config.js` pribadi.

## Catatan finansial
- `Net Movement` adalah cash in minus cash out, bukan laba akuntansi.
- `Non-capital Net` mengecualikan transaksi bertipe `CAPITAL` agar modal/carry-over tidak mendominasi pembacaan arus kas.
- `Obligations` masih berbasis keyword kategori; untuk AR/AP akurat dibutuhkan counterparty, direction (receivable/payable), due date, status, invoice/ref.
- Kolom ORIGIN berubah semantik antara periode awal dan periode berikutnya; dashboard menormalisasi label tetapi tidak mengubah data sumber.
